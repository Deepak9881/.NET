namespace BOL;
public class Department
{
    public int Id{get; set;}
    public String? Name{get; set;}
    public String? Location{get; set;}
}