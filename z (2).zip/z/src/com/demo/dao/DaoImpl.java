package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.beans.MyUser;

public class DaoImpl implements Dao{
	private static Connection con;
	private static PreparedStatement  psau;
	
	static {
		con= DButil.getMyConnection();
		try {
			psau=con.prepareStatement("insert into Customer values(?,?,?)");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addUser( MyUser mu) {
		try {
			
			
			psau.setString(1, mu.getfName());
			psau.setString(2, mu.getLname());
			psau.setString(3, mu.getAddress());
			psau.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		}

}
