package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DButil {
	private static Connection con;
	
	public static Connection getMyConnection()
	{
		try {
			if(con==null)
			{
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				String url = "jdbc:mysql://192.168.10.150:3306/dac43_campus?useSSL=false";
				con=DriverManager.getConnection(url,"dac43","welcome");
				if(con!=null)
				{
					System.out.println("connection done");
				}
			}
		}catch(SQLException e)
		{
			System.out.println("DButil error");
			return null;
		}
		return con;
	}
	
	public static void closeConnection()
	{
		try {
			if(con!=null)
				con.close();
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}
