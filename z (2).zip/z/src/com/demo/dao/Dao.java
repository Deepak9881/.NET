package com.demo.dao;

import com.demo.beans.MyUser;

public interface Dao {
	
	public void addUser(MyUser mu);

}
