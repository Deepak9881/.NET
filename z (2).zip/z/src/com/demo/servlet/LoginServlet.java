package com.demo.servlet;


	
	import java.io.IOException;
	import java.io.PrintWriter;

	import com.demo.service.LoginService;
	import com.demo.service.LoginServiceImpl;
	import com.demo.beans.MyUser;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	public class LoginServlet extends HttpServlet{
		public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
		{
			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			String fname=req.getParameter("fname");
			String lname=req.getParameter("lname");
			String address=req.getParameter("address");
			MyUser mu = new MyUser(fname, lname, address);
			LoginService ls = new LoginServiceImpl(); 
			ls.addUser(mu);
			
			
			RequestDispatcher rd = req.getRequestDispatcher("Login.html");
			rd.include(req, res);
			
					
		}
		

}
