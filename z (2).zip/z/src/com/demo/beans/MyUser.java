package com.demo.beans;

public class MyUser {
	private String fName;
	private String Lname;
	private String address;
	
	public MyUser() {
		super();
	}
	
	public MyUser(String fName, String lname, String address) {
		super();
		this.fName = fName;
		Lname = lname;
		this.address = address;
	}
	
	public String getfName() {
		return fName;
	}
	
	public void setfName(String fName) {
		this.fName = fName;
	}
	
	public String getLname() {
		return Lname;
	}
	
	public void setLname(String lname) {
		Lname = lname;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "MyUser [fName=" + fName + ", Lname=" + Lname + ", address=" + address + "]";
	}
	
}
