package com.demo.service;

import com.demo.dao.*;
import com.demo.beans.MyUser;

public class LoginServiceImpl implements LoginService{
	public static Dao dao;
	static {
		dao = new DaoImpl();
	}
	
	public void addUser(MyUser mu) {
		dao.addUser(mu);
	}

}
