package com.demo.Question2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Question2.Beans.Product;
import com.demo.Question2.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService ps;
	@GetMapping("/products")
	public List<Product>   displayAllProducts() {
		List<Product> plist=ps.getProducts();
		return plist;
		
	}
	
	@PostMapping("/add/{pname}")
	public ResponseEntity<String> insertProduct( @RequestBody Product p) {
		  ps.addProduct(p);
		  return ResponseEntity.ok("added successfully");
	}
	
	
}
