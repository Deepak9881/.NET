package com.demo.Question2.Beans;

import org.springframework.beans.factory.annotation.Value;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@Entity
public class Product {
	@Id
private String pname;
@Min(value = 1)
@Max(value = 10)
private int rating;
public Product() {
	super();
}
public Product(String pname, @Min(1) @Max(10) int rating) {
	super();
	this.pname = pname;
	this.rating = rating;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public int getRating() {
	return rating;
}
public void setRating(int rating) {
	this.rating = rating;
}
@Override
public String toString() {
	return "Product [pname=" + pname + ", rating=" + rating + "]";
}

}
