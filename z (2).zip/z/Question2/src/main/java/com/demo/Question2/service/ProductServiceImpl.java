package com.demo.Question2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Question2.Beans.Product;
import com.demo.Question2.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDao pd;
	@Override
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		pd.save(p);
	}
	@Override
	public List<Product> getAllRatings() {
		// TODO Auto-generated method stub
		List<Product> pl=pd.findAll();
		return pl;
	}
	@Override
	public List<Product> getProducts() {
		List<Product> pll=pd.findAll();
		return pll;
	}

}
