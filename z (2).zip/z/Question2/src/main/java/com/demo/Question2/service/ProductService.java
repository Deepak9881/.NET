package com.demo.Question2.service;

import java.util.List;

import com.demo.Question2.Beans.Product;

public interface ProductService {

	void addProduct(Product p);

	List<Product> getAllRatings();

	List<Product> getProducts();

}
