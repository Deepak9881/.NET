package com.demo.Question2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.demo.Question2.Beans.Product;
import com.demo.Question2.service.ProductService;

@Controller
public class MvcController {
	@Autowired
	ProductService ps;
	 @GetMapping("/getAllRatings")
	  public ModelAndView displayAllProduct() {
		  List<Product> plist=ps.getAllRatings();
		  return new ModelAndView("displayproduct","plist",plist);
	  }
}
