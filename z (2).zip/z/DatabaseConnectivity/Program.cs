﻿using HR;
using Testing;


// ******************************************************************
List<Department> dlist=new List<Department>();
// dlist=DBTestManager.getAllDepartment();
// foreach(Department d in dlist)
// {
//     Console.WriteLine(d.Id+" "+d.Name+" "+d.Location);

// }
// ******************************************************************


// Department d = DBTestManager.GetDepartmentById(4);
// Console.WriteLine(d.Id+" "+d.Name+" "+d.Location);
// ******************************************************************

Department d=new Department{
    Id=6,
    Name="sumi",
    Location="vidharbha"
};
bool status=DBTestManager.Insert(d);
if(status)
{
    Console.WriteLine("Insert sucessfully");
}
else{
    Console.WriteLine("Not Inserted");
}
// ******************************************************************

// Department d1=new Department{
//     Id=14,
//     Name="suyog",
//     Location="Abad"
// };

// bool status=DBTestManager.Update(d1);
// if(status)
// {
//     Console.WriteLine("Updated sucessfully");
// }
// else{
//     Console.WriteLine("Not Updated");
// }
// ******************************************************************

// bool status=DBTestManager.Delete(14);
// if(status)
// {
//     Console.WriteLine("Deleted sucessfully");
// }
// else{
//     Console.WriteLine("Not Deleted");
// }

