﻿namespace DAL;
using BOL;
using System.Collections.Generic;
using MySql.Data.MySqlClient;

public class DBManager
{
    public static string conString=@"server=192.168.10.150;port=3306;user=dac27;password=welcome;database=dac27";


    public static List<Student> GetAllStudents(){
        List<Student> slist=new List<Student>();
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=conString;
        string query="select Srno,studentname from feedback";

        MySqlCommand cmd = new MySqlCommand(query,con);

        try{
            con.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read()){
                int no=int.Parse(reader["Srno"].ToString());
                string name=reader["studentname"].ToString();

                Student s=new Student{
                            StudentId=no,
                            StudentName=name };

             slist.Add(s);   
            }
        }catch(Exception e){
            Console.WriteLine(e.Message);
        }finally{
            con.Close();
        }
        return slist;

    

    }

    public static List<Topic> GetAllTopic(){
        List<Topic> tlist=new List<Topic>();
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=conString;
        string query="select tid,tname from topic";

        MySqlCommand cmd = new MySqlCommand(query,con);

        try{
            con.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read()){
                int no=int.Parse(reader["tid"].ToString());
                string name=reader["tname"].ToString();

                Topic t=new Topic{
                            TId=no,
                            TName=name };

             tlist.Add(t);   
            }
        }catch(Exception e){
            Console.WriteLine(e.Message);
        }finally{
            con.Close();
        }
        return tlist;
    }


}

//Database table creation commands
//create table feedback(Srno int primary key auto_increment,studentname varchar(80),fdate date, tname varchar(20), 
//module varchar(20),faculty varchar(20),PSR int,PreSkill int,Comments varchar(250));
// create table topic(tid int primary key auto_increment, tname varchar(80));