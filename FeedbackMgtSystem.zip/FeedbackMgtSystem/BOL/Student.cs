﻿namespace BOL;

//POCO class for Student
public class Student
{
    //Declaring AutoProperty
    public int StudentId{get;set;}
    public string StudentName{get;set;}
    
    //Default Construtor
    public Student(){}
    
    //Parameterized Constructor
    public Student(string name){
        this.StudentName=name;
    }
    
    public Student(int id,string name){
        this.StudentId=id;
        this.StudentName=name;
        }

    //Tostring to print the all properties of class
    public override string ToString(){
        return base.ToString()+" Student Id: "+this.StudentId+" Student Name: "+this.StudentName;
    }


}
