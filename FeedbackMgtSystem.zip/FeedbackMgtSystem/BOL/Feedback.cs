namespace BOL;


public class Feedback
{
   public DateOnly FDate{get;set;}
   public string StudentName{get;set;}
   public string Module{get;set;}
   public string Faculty{get;set;}
   public int PSRating{get;set;}
   public int PreSkill{get;set;}
   public string Comments{get;set;}


    public Feedback(){}

    public Feedback(DateOnly date,string sname,string module,int psr,int preskill,string comm,string faculty){
        this.FDate=date;
        this.StudentName=sname;
        this.Module=module;
        this.PSRating=psr;
        this.PreSkill=preskill;
        this.Comments=comm;
        this.Faculty=faculty;
    }


    public override string ToString(){
        return base.ToString()+"Feedback Date= "+this.FDate+
                                "\n Module= "+this.Module+
                                "\n Faculty= "+this.Faculty+
                                "\n Problem Solving Rating= "+this.PSRating+
                                "\n Presentation Skill= "+this.PreSkill+
                                "\n Comments= "+this.Comments;
    }


        
}
