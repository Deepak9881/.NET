namespace BOL;


public class Topic
{
     public int TId{get;set;}
     public string TName{get;set;}

     public Topic(){} 

     public Topic(string tname){
       this.TName=tname;
     }  

     public override string ToString(){
         return base.ToString()+" Topic Id= "+this.TId+
                                 "\n Topic Name= "+this.TName;
     }
}
