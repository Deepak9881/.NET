using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using FeedbackSystem.Models;
using BOL;
using BLL;
using System.Collections.Generic;

namespace FeedbackSystem.Controllers;

    public class FeedbackController:Controller
    {
         private readonly ILogger<FeedbackController> _logger;

    public FeedbackController(ILogger<FeedbackController> logger)
    {
        _logger = logger;
    }

    public ActionResult GetAllStudents(){

        List<Student>slist=Service.GetAll();
         
        this.ViewData["stlist"]=slist;
        return View();
    }


    [HttpPost]
    public ActionResult AddFeedback(int srno, string stdname, string tname, DateOnly date, 
                                    string module, string faculty, string psr, 
                                    string ps, string comment){
            Feedback f=new Feedback(date,stname,module,int.Parse(psr.ToString),int.Parse(ps.ToString(),)
         
  


//DateOnly date,string sname,string module,int psr,int preskill,string comm
        return RedirectToAction("GetAllStudents");
    }






        
    //       public IActionResult AddFeedback(int srno, string stdname, string tname, DateOnly date, 
    //                                 string module, string faculty, string psr, string ps, string comment)
    // {
    //     // List<StudentFeedback> slist = Service.GetAllStudent();
        
    //     // this.ViewData["StudentList"]=slist;

    //     return RedirectToAction("StudentList");
    // }
    }
