using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using FeedbackSystem.Models;
using BOL;
using BLL;
using System.Collections.Generic;
namespace FeedbackSystem.Controllers;

public class TopicController:Controller
{

     private readonly ILogger<TopicController> _logger;

    public TopicController(ILogger<TopicController> logger)
    {
        _logger = logger;
    
   
    }
    
     public IActionResult TopicList()
    {
        List<Topic> tlist = Service.GetAllTopic();
        
        this.ViewData["tlist"]=tlist;

        return View();
    }
}
