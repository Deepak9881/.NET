﻿using BOL;
using DAL;
using System.Collections.Generic;
namespace BLL;

public class Service
{
   public static List<Student> GetAll(){
       
       return DBManager.GetAllStudents();
   }

  public static List<Topic> GetAllTopic(){
       
       return DBManager.GetAllTopic();
   }
  
}
