﻿using BankingLib;
using TaxHandlersLib;
using TaxPolicyLib;

Account ac=new Account();

ac.balance=10000;

double amount=15000;
ac.Deposit(amount);

Console.WriteLine("Balance after deposit={0}",ac.balance);

TaxHandler handler=new TaxHandler();
double totalamount=handler.PayIncomeTax(ac.balance);
Console.WriteLine("Amount After Tax deduction={0}",totalamount);
TaxDelegate opr1=new TaxDelegate(handler.PayIncomeTax);
TaxDelegate opr2=new TaxDelegate(handler.PaySalesTax);
TaxDelegate opr3=new TaxDelegate(handler.PayPropertyTax);

TaxDelegate delegatemgr=opr1;
delegatemgr+=opr2;
delegatemgr+=opr3;

double finalamount=delegatemgr(ac.balance);
ac.balance=finalamount;
Console.WriteLine("Final Amount after all iterations={0}",ac.balance);