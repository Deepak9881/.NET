﻿namespace BankingLib;
using TaxPolicyLib;

public class Account
{
    public event TaxDelegate overBalance;
    public event TaxDelegate underBalance;
    public double balance{get;set;}


    public void Deposit(double amount){
     this.balance+=amount;
     if(this.balance>50000){
         this.balance=overBalance(this.balance);
     }
    }

    public void Withdraw(double amount){
        this.balance-=amount;

         if(this.balance<5000){
            this.balance=underBalance(this.balance);
        }
    }

}
