﻿using BankingLib;
using TaxPolicyLib;
using TaxHandlersLib;

Account acc=new Account();
TaxHandler handler=new TaxHandler();
acc.balance=5000;

acc.overBalance+=handler.PayIncomeTax;
acc.overBalance+=handler.PaySalesTax;
acc.overBalance+=handler.PayIncomeTax;

acc.Deposit(55000);

Console.WriteLine("Final balance after deductions={0}",acc.balance);

acc.underBalance+=handler.LowBalance;
acc.Withdraw(50000);
Console.WriteLine("Lowbalance={0} ",acc.balance);
