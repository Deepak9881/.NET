﻿namespace TaxHandlersLib;

public class TaxHandler
{
    public double PayIncomeTax(double amount){
        double balance=0.8*amount;
        Console.WriteLine("Tax deducted={0}",0.2*amount);
        return balance;
    }
    public double PaySalesTax(double amount){
        double balance=0.95*amount;
        Console.WriteLine("Tax deducted={0}", 0.05*amount);
        return balance;
    }

    public double PayPropertyTax(double amount){
        double balance=0.7*amount;
        Console.WriteLine("Tax Deducted={0}",0.3*amount);
        return balance;
    }

    public double LowBalance(double amount){
        Console.WriteLine("Account balance is low ");
        return amount;
    }

}
