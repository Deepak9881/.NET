﻿namespace TaxPolicyLib;

public delegate double TaxDelegate(double amount);
