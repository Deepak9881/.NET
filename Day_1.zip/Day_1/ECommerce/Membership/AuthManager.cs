﻿namespace Membership;

public class AuthManager
{
   public bool validate(string email,string password){
       bool status=false;
       if(email=="gaurava@gmail.com" && password=="123"){
           status=true;
       }
       return status;
   }
}
