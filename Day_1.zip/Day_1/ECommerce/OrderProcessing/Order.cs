﻿namespace OrderProcessing;

public class Order
{
    public int Orderid{get;set;}
    public DateTime OrderDate{get;set;}
    public float SubTotal{get;set;}
    public string status{get;set;}


}
