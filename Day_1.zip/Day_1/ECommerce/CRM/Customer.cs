﻿namespace CRM;

public class Customer
{
    public string FirstName{get;set;}
    public string LastName{get;set;}
    public string email{get;set;}
    public string ContactNo{get;set;}

}
