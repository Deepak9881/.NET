﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using catalog;
using CRM;
using Membership;
using Shoppingcart;
using OrderProcessing;

Product p=new Product{
                     Id=1,
                     Pname="Chocolate",
                     Quantity=10,
                     UnitPrice=15};
        
Console.WriteLine(p.Id+" "+p.Pname);