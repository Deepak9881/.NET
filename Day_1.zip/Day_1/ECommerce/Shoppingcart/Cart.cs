﻿using System.Collections.Generic;
namespace Shoppingcart;

public class Cart5
{
   public List<Item> Items{get;set;}
   public void AddtoCart(Item i){
       Items.Add(i);
   }

   public void RemoveFromCart(Item i){
       Items.Remove(i);
   }

}
