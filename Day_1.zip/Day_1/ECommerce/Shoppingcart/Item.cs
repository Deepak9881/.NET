using System.Collections.Generic;
namespace Shoppingcart;
using catalog;
public class Item{

    public Product p1;
    public int Quantity{get;set;}
    

}