﻿namespace DAL;
using MySql.Data.MySqlClient;
//using.System.Collections.Generic;
using BOL;
public class DBManager{

  public static string conString=@"server=192.168.10.150;port=3306;user=dac27; password=welcome;database=dac27"; 

  public static List<Productss> GetAllProducts(){
      List<Productss> plist=new List<Productss>();
      MySqlConnection con=new MySqlConnection();
      con.ConnectionString=conString;
      string query="select * from productss";
      try{
          MySqlCommand cmd=new MySqlCommand();
          cmd.Connection=con;
          con.Open();
          cmd.CommandText=query;
          MySqlDataReader reader=cmd.ExecuteReader();
          while(reader.Read()){
              int pid=int.Parse(reader["prodid"].ToString());
              string name=reader["pname"].ToString();
              Console.WriteLine("Product name"+name);
              int qty=int.Parse(reader["Quantity"].ToString());
              float pe=float.Parse(reader["price"].ToString());
          
          Productss p=new Productss{prodid=pid,
                                   pname=name,
                                   Quantity=qty,
                                   price=pe
                           
                                   };
                                   Console.WriteLine(p);
          plist.Add(p);
      }
          return plist;
      }catch(Exception e){

      }finally{
         con.Close();
      }
      return plist;
  }

    public static void AddProduct(Productss p){
        string query = "INSERT INTO Productss "+
                            "VALUES(" + p.prodid + ",'" + p.pname + "'," + p.Quantity + "," + p.price + ")";
        Console.WriteLine(query);
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try{
            con.Open();
            MySqlCommand command = new MySqlCommand(query, con);
            command.ExecuteNonQuery();
  
        } 
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }               
     
    }


      public static void UpdateProduct(int id,string name)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try
        {
            string query = "UPDATE productss SET pname='" + name + "' WHERE prodid=" +id;
            MySqlCommand command = new MySqlCommand(query, con);
            con.Open();
            command.ExecuteNonQuery();
      
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }

    }
        public static void DeleteProduct(int id)
    {
        MySqlConnection con = new MySqlConnection();
        con.ConnectionString = conString;
        try
        {
            string query = "Delete from productss WHERE prodid=" +id;
            MySqlCommand command = new MySqlCommand(query, con);
            con.Open();
            command.ExecuteNonQuery();
      
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            con.Close();
        }

    }

}
