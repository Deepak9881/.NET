﻿namespace BOL;

public class Productss
{
    public int prodid{get;set;}
    public string pname{get;set;}
    public int Quantity{get;set;}
    public float price{get;set;}


    public Productss(){
        this.prodid=0;
        this.pname=null;
        this.Quantity=0;
        this.price=0;
    }

    public Productss(int id,string name,int qty,int price){
        this.prodid=id;
        this.pname=name;
        this.Quantity=qty;
        this.price=price;
    }

    public string ToString(){
        return " Product Id: "+this.prodid+"\n"+
                                "Product Name: "+this.pname+
                                "\n Quantity: "+this.Quantity+
                                "\n Price: "+this.price;
    }
}