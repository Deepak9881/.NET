﻿using DAL;
using BOL;

List<Productss> plist=DBManager.GetAllProducts();
foreach(Productss p in plist){
    Console.WriteLine(p);
}

Console.WriteLine("Enter the product id");
int id=int.Parse(Console.ReadLine());
Console.WriteLine("Enter the Product name");
string name=Console.ReadLine();
Console.WriteLine("Enter the quantity");
int qty=int.Parse(Console.ReadLine());
Console.WriteLine("Enter the Price");
float price=float.Parse(Console.ReadLine());
Productss p1=new Productss{prodid=id,
                           pname=name,
                           Quantity=qty,
                           price=price};
DBManager.AddProduct(p1);

 plist=DBManager.GetAllProducts();
foreach(Productss p in plist){
    Console.WriteLine(p);
}
 Console.WriteLine("Enter the product id to be modidfied");
 id=int.Parse(Console.ReadLine());
Console.WriteLine("Enter the Product name");
 name=Console.ReadLine();
 
DBManager.UpdateProduct(id,name);
foreach(Productss p in plist){
    Console.WriteLine(p);
}

 Console.WriteLine("Enter the product id to be modidfied");
 int id=int.Parse(Console.ReadLine());
 DBManager.DeleteProduct(id);
